from exifgpseditor.exifgpseditor import run

def main():
    run()
